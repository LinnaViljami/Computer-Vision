disp('				'); 
disp('**************************************				'); 
disp('				'); 
disp(' 	Thanks for using Snake Demo!'); 
disp('				'); 
disp(' 	Good bye and have a nice day!'); 
disp('				'); 
disp('**************************************				'); 
delete(get(0,'CurrentFigure')); 